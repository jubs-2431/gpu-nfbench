# GPU-NFBench Artifact Bundle

This bundle contains the conference paper, benchmark data, evaluation tables, annotation audit packet, and data card for GPU-NFBench.
It also includes a reproducibility guide, a 250-row evidence-coded root-cause extension, and an external-repository candidate pool for future expansion.

Recommended archival release steps:

1. Create a public GitHub repository named `gpu-nfbench`.
2. Upload this bundle without private keys, local caches, or virtual environments.
3. Add a release tag such as `v1.0-conference`.
4. Archive the tagged release on Zenodo and include the DOI in the paper.
5. Review audit-vs-gold disagreements before using audit labels to revise the benchmark.

Primary paper file: `paper/GPU-NFBench_IEEE_Manuscript.pdf`
Primary benchmark file: `data/processed/gold_benchmark_expanded_v2_canonical.csv`
